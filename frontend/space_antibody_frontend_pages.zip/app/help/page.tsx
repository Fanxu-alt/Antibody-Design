import Navbar from "../components/Navbar";
import SectionTitle from "../components/SectionTitle";

export default function HelpPage() {
  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      <Navbar />

      <section className="mx-auto max-w-7xl px-8 py-12">
        <div className="rounded-3xl border bg-white p-8 shadow-sm">
          <SectionTitle
            label="Guide"
            title="Help"
            description="For non-coding users, the recommended workflow is to provide an antigen sequence, a heavy-chain template, and the template CDRH3, then run the full design pipeline."
          />

          <div className="grid gap-6 md:grid-cols-3">
            <div className="rounded-2xl border bg-slate-50 p-6">
              <h3 className="mb-2 font-bold">1. Generate</h3>
              <p className="text-sm leading-6 text-slate-600">
                Paste an antigen sequence and generate candidate CDRH3 sequences.
              </p>
            </div>

            <div className="rounded-2xl border bg-slate-50 p-6">
              <h3 className="mb-2 font-bold">2. Predict</h3>
              <p className="text-sm leading-6 text-slate-600">
                Paste a heavy-chain sequence and antigen sequence to predict
                antibody-antigen binding probability.
              </p>
            </div>

            <div className="rounded-2xl border bg-slate-50 p-6">
              <h3 className="mb-2 font-bold">3. Developability</h3>
              <p className="text-sm leading-6 text-slate-600">
                Run the complete workflow to generate, graft, predict, rank, and
                export antibody candidates.
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
