"use client";

import { useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import SectionTitle from "../components/SectionTitle";

export default function DownloadPage() {
  const [downloadUrl, setDownloadUrl] = useState("");

  useEffect(() => {
    const saved = localStorage.getItem("space_latest_download_url");
    if (saved) {
      setDownloadUrl(saved);
    }
  }, []);

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      <Navbar />

      <section className="mx-auto max-w-7xl px-8 py-12">
        <div className="rounded-3xl border bg-white p-8 shadow-sm">
          <SectionTitle
            label="Export"
            title="Download"
            description="Download the latest full-pipeline result table as a CSV file after running the developability workflow."
          />

          {downloadUrl ? (
            <a
              href={downloadUrl}
              download
              className="inline-block rounded-full bg-slate-900 px-5 py-2 text-sm font-semibold text-white"
            >
              Download latest CSV
            </a>
          ) : (
            <p className="text-sm text-slate-500">
              No result file is available yet. Run the Developability workflow
              first.
            </p>
          )}
        </div>
      </section>
    </main>
  );
}
