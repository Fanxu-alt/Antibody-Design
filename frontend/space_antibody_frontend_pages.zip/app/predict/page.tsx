"use client";

import { useState } from "react";
import Navbar from "../components/Navbar";
import SectionTitle from "../components/SectionTitle";
import {
  API_BASE,
  DEFAULT_ANTIGEN,
  DEFAULT_HEAVY,
  formatNumber,
} from "../components/config";

type BindingResult = {
  binding_probability?: number;
  logit?: number;
};

export default function PredictPage() {
  const [heavy, setHeavy] = useState(DEFAULT_HEAVY);
  const [antigen, setAntigen] = useState(DEFAULT_ANTIGEN);
  const [result, setResult] = useState<BindingResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function runPredict() {
    setLoading(true);
    setError("");
    setResult(null);

    try {
      const response = await fetch(`${API_BASE}/predict-binding`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          heavy_seq: heavy,
          antigen_seq: antigen,
        }),
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(`API error: ${response.status} ${text}`);
      }

      const data = await response.json();
      setResult(data);
    } catch (err) {
      setError(String(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      <Navbar />

      <section className="mx-auto max-w-7xl px-8 py-12">
        <div className="rounded-3xl border bg-white p-8 shadow-sm">
          <SectionTitle
            label="Module 02"
            title="Predict"
            description="Predict antibody-antigen binding probability for a heavy-chain sequence and antigen sequence pair."
          />

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-semibold">
                Heavy-chain sequence
              </label>
              <textarea
                className="h-40 w-full rounded-xl border p-4 font-mono text-sm"
                value={heavy}
                onChange={(event) => setHeavy(event.target.value)}
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold">
                Antigen sequence
              </label>
              <textarea
                className="h-40 w-full rounded-xl border p-4 font-mono text-sm"
                value={antigen}
                onChange={(event) => setAntigen(event.target.value)}
              />
            </div>
          </div>

          <button
            onClick={runPredict}
            disabled={loading || heavy.trim().length === 0 || antigen.trim().length === 0}
            className="mt-6 rounded-full bg-blue-700 px-6 py-3 font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-400"
          >
            {loading ? "Predicting..." : "Predict binding"}
          </button>

          {error && (
            <div className="mt-6 rounded-xl border border-red-200 bg-red-50 p-4 text-red-700">
              {error}
            </div>
          )}

          {result && (
            <div className="mt-8 grid gap-4 md:grid-cols-2">
              <div className="rounded-2xl border bg-slate-50 p-6">
                <p className="text-sm text-slate-600">Binding probability</p>
                <p className="mt-2 text-3xl font-bold text-blue-700">
                  {formatNumber(result.binding_probability)}
                </p>
              </div>

              <div className="rounded-2xl border bg-slate-50 p-6">
                <p className="text-sm text-slate-600">Logit</p>
                <p className="mt-2 text-3xl font-bold text-blue-700">
                  {formatNumber(result.logit)}
                </p>
              </div>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
