"use client";

import { useState } from "react";
import Navbar from "../components/Navbar";
import SectionTitle from "../components/SectionTitle";
import {
  API_BASE,
  DEFAULT_ANTIGEN,
  DEFAULT_CDRH3,
  DEFAULT_HEAVY,
  TARGETS,
  formatNumber,
} from "../components/config";

type PipelineResult = {
  rank?: number;
  candidate_name: string;
  cdrh3: string;
  heavy_chain?: string;
  binding_probability?: number;
  binding_logit?: number;
  developability_risk_score?: number;
  hard_filter_pass?: boolean;
};

export default function DevelopabilityPage() {
  const [antigen, setAntigen] = useState(DEFAULT_ANTIGEN);
  const [targetName, setTargetName] = useState("hiv_gp120");
  const [templateHeavy, setTemplateHeavy] = useState(DEFAULT_HEAVY);
  const [templateCdrh3, setTemplateCdrh3] = useState(DEFAULT_CDRH3);
  const [numSamples, setNumSamples] = useState(5);
  const [results, setResults] = useState<PipelineResult[]>([]);
  const [downloadUrl, setDownloadUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function runPipeline() {
    setLoading(true);
    setError("");
    setResults([]);
    setDownloadUrl("");

    try {
      const response = await fetch(`${API_BASE}/full-pipeline`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          antigen,
          target_name: targetName,
          template_heavy: templateHeavy,
          template_cdrh3: templateCdrh3,
          num_samples: numSamples,
          min_len: 8,
          sample_mode: "sample",
          temperature: 1.0,
          deduplicate: true,
        }),
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(`API error: ${response.status} ${text}`);
      }

      const data = await response.json();
      setResults(data.results || []);
      setDownloadUrl(data.download_url || "");
      localStorage.setItem("space_latest_download_url", data.download_url || "");
    } catch (err) {
      setError(String(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      <Navbar />

      <section className="mx-auto max-w-7xl px-8 py-12">
        <div className="rounded-3xl border bg-white p-8 shadow-sm">
          <SectionTitle
            label="Module 03"
            title="Developability"
            description="Run the full SPACE workflow: generate CDRH3 candidates, graft them into a heavy-chain template, predict binding, and rank candidates by developability."
          />

          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <label className="mb-2 block text-sm font-semibold">Target name</label>
              <select
                value={targetName}
                onChange={(event) => setTargetName(event.target.value)}
                className="w-full rounded-xl border p-3"
              >
                {TARGETS.map((target) => (
                  <option key={target} value={target}>
                    {target}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-2 block text-sm font-semibold">
                Number of candidates
              </label>
              <input
                type="number"
                min={1}
                max={20}
                value={numSamples}
                onChange={(event) => setNumSamples(Number(event.target.value))}
                className="w-full rounded-xl border p-3"
              />
            </div>
          </div>

          <div className="mt-4">
            <label className="mb-2 block text-sm font-semibold">Antigen sequence</label>
            <textarea
              className="h-36 w-full rounded-xl border p-4 font-mono text-sm"
              value={antigen}
              onChange={(event) => setAntigen(event.target.value)}
            />
          </div>

          <div className="mt-4">
            <label className="mb-2 block text-sm font-semibold">
              Heavy-chain template
            </label>
            <textarea
              className="h-36 w-full rounded-xl border p-4 font-mono text-sm"
              value={templateHeavy}
              onChange={(event) => setTemplateHeavy(event.target.value)}
            />
          </div>

          <div className="mt-4">
            <label className="mb-2 block text-sm font-semibold">Template CDRH3</label>
            <input
              className="w-full rounded-xl border p-3 font-mono text-sm"
              value={templateCdrh3}
              onChange={(event) => setTemplateCdrh3(event.target.value)}
            />
          </div>

          <button
            onClick={runPipeline}
            disabled={
              loading ||
              antigen.trim().length === 0 ||
              templateHeavy.trim().length === 0 ||
              templateCdrh3.trim().length === 0
            }
            className="mt-6 rounded-full bg-blue-700 px-6 py-3 font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-400"
          >
            {loading ? "Running full pipeline..." : "Run Full Pipeline"}
          </button>

          {error && (
            <div className="mt-6 rounded-xl border border-red-200 bg-red-50 p-4 text-red-700">
              {error}
            </div>
          )}

          {results.length > 0 && (
            <div className="mt-8">
              <div className="mb-4 flex items-center justify-between gap-4">
                <h3 className="text-2xl font-bold">Ranked antibody candidates</h3>
                {downloadUrl && (
                  <a
                    href={downloadUrl}
                    download
                    className="rounded-full bg-slate-900 px-5 py-2 text-sm font-semibold text-white"
                  >
                    Download CSV
                  </a>
                )}
              </div>

              <div className="overflow-x-auto rounded-2xl border">
                <table className="w-full border-collapse bg-white text-sm">
                  <thead className="bg-slate-100 text-left">
                    <tr>
                      <th className="border-b p-3">Rank</th>
                      <th className="border-b p-3">Candidate</th>
                      <th className="border-b p-3">CDRH3</th>
                      <th className="border-b p-3">Binding probability</th>
                      <th className="border-b p-3">Binding logit</th>
                      <th className="border-b p-3">Developability risk</th>
                      <th className="border-b p-3">Pass filter</th>
                    </tr>
                  </thead>

                  <tbody>
                    {results.map((row, index) => (
                      <tr key={`${row.candidate_name}-${index}`} className="hover:bg-slate-50">
                        <td className="border-b p-3">{row.rank ?? index + 1}</td>
                        <td className="border-b p-3">{row.candidate_name}</td>
                        <td className="border-b p-3 font-mono font-semibold text-blue-700">
                          {row.cdrh3}
                        </td>
                        <td className="border-b p-3">
                          {formatNumber(row.binding_probability)}
                        </td>
                        <td className="border-b p-3">{formatNumber(row.binding_logit)}</td>
                        <td className="border-b p-3">
                          {formatNumber(row.developability_risk_score)}
                        </td>
                        <td className="border-b p-3">
                          {typeof row.hard_filter_pass === "boolean"
                            ? String(row.hard_filter_pass)
                            : "NA"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
