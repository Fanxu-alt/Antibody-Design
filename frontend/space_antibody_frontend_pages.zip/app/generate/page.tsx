"use client";

import { useState } from "react";
import Navbar from "../components/Navbar";
import SectionTitle from "../components/SectionTitle";
import { API_BASE, DEFAULT_ANTIGEN } from "../components/config";

type GeneratedCandidate = {
  antigen?: string;
  cdrh3: string;
  pred_len?: number;
  sample_mode?: string;
  temperature?: number;
};

export default function GeneratePage() {
  const [antigen, setAntigen] = useState(DEFAULT_ANTIGEN);
  const [numSamples, setNumSamples] = useState(5);
  const [results, setResults] = useState<GeneratedCandidate[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function runGenerate() {
    setLoading(true);
    setError("");
    setResults([]);

    try {
      const response = await fetch(`${API_BASE}/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          antigen,
          num_samples: numSamples,
          min_len: 8,
          sample_mode: "sample",
          temperature: 1.0,
          deduplicate: true,
        }),
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(`API error: ${response.status} ${text}`);
      }

      const data = await response.json();
      setResults(data.candidates || []);
    } catch (err) {
      setError(String(err));
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-slate-50 text-slate-900">
      <Navbar />

      <section className="mx-auto max-w-7xl px-8 py-12">
        <div className="rounded-3xl border bg-white p-8 shadow-sm">
          <SectionTitle
            label="Module 01"
            title="Generate"
            description="Generate antigen-conditioned CDRH3 candidates from an input antigen sequence."
          />

          <label className="mb-2 block text-sm font-semibold">
            Antigen amino-acid sequence
          </label>

          <textarea
            className="h-48 w-full rounded-xl border p-4 font-mono text-sm"
            value={antigen}
            onChange={(event) => setAntigen(event.target.value)}
          />

          <div className="mt-4 flex flex-wrap items-center gap-4">
            <div>
              <label className="mb-1 block text-sm font-semibold">
                Number of candidates
              </label>
              <input
                type="number"
                min={1}
                max={50}
                value={numSamples}
                onChange={(event) => setNumSamples(Number(event.target.value))}
                className="w-32 rounded-xl border p-3"
              />
            </div>

            <button
              onClick={runGenerate}
              disabled={loading || antigen.trim().length === 0}
              className="mt-6 rounded-full bg-blue-700 px-6 py-3 font-semibold text-white disabled:cursor-not-allowed disabled:bg-slate-400"
            >
              {loading ? "Generating..." : "Generate CDRH3"}
            </button>
          </div>

          {error && (
            <div className="mt-6 rounded-xl border border-red-200 bg-red-50 p-4 text-red-700">
              {error}
            </div>
          )}

          {results.length > 0 && (
            <div className="mt-8 overflow-x-auto rounded-2xl border">
              <table className="w-full border-collapse bg-white text-sm">
                <thead className="bg-slate-100 text-left">
                  <tr>
                    <th className="border-b p-3">Rank</th>
                    <th className="border-b p-3">CDRH3</th>
                    <th className="border-b p-3">Predicted length</th>
                    <th className="border-b p-3">Sampling mode</th>
                    <th className="border-b p-3">Temperature</th>
                  </tr>
                </thead>

                <tbody>
                  {results.map((row, index) => (
                    <tr key={`${row.cdrh3}-${index}`} className="hover:bg-slate-50">
                      <td className="border-b p-3">{index + 1}</td>
                      <td className="border-b p-3 font-mono font-semibold text-blue-700">
                        {row.cdrh3}
                      </td>
                      <td className="border-b p-3">{row.pred_len ?? "NA"}</td>
                      <td className="border-b p-3">{row.sample_mode ?? "NA"}</td>
                      <td className="border-b p-3">{row.temperature ?? "NA"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
